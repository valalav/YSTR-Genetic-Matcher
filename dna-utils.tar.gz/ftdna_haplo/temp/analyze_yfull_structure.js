const fs = require('fs');

// Функция для анализа структуры объекта
function analyzeStructure(obj, level = 0, path = '') {
    if (!obj) return;
    
    console.log(`${'  '.repeat(level)}Level ${level}${path ? ' at ' + path : ''}:`);
    
    if (Array.isArray(obj)) {
        console.log(`${'  '.repeat(level)}Array of ${obj.length} items`);
        if (obj.length > 0) {
            console.log(`${'  '.repeat(level)}Sample item:`);
            analyzeStructure(obj[0], level + 1, `${path}[0]`);
        }
        return;
    }

    if (typeof obj !== 'object') {
        console.log(`${'  '.repeat(level)}Value: ${obj}`);
        return;
    }

    // Анализируем поля объекта
    for (const [key, value] of Object.entries(obj)) {
        const newPath = path ? `${path}.${key}` : key;
        
        if (Array.isArray(value)) {
            console.log(`${'  '.repeat(level)}${key}: Array[${value.length}]`);
            if (value.length > 0) {
                analyzeStructure(value[0], level + 1, `${newPath}[0]`);
            }
        } else if (typeof value === 'object' && value !== null) {
            console.log(`${'  '.repeat(level)}${key}: Object`);
            analyzeStructure(value, level + 1, newPath);
        } else {
            console.log(`${'  '.repeat(level)}${key}: ${value}`);
        }
    }
}

// Функция для поиска определенных паттернов в данных
function findPatterns(obj) {
    const patterns = {
        snpCount: 0,
        maxDepth: 0,
        uniqueFields: new Set(),
        sampleNodes: []
    };

    function traverse(node, depth = 0) {
        if (!node) return;

        // Увеличиваем максимальную глубину
        patterns.maxDepth = Math.max(patterns.maxDepth, depth);

        // Собираем уникальные поля
        if (typeof node === 'object') {
            Object.keys(node).forEach(key => patterns.uniqueFields.add(key));
        }

        // Собираем примеры узлов на разных уровнях
        if (patterns.sampleNodes.length < 5 && node.name) {
            patterns.sampleNodes.push({
                name: node.name,
                depth: depth,
                fields: Object.keys(node)
            });
        }

        // Считаем SNP если они есть
        if (node.snps) {
            patterns.snpCount += Array.isArray(node.snps) ? node.snps.length : 1;
        }

        // Рекурсивно обходим дочерние узлы
        if (node.children) {
            node.children.forEach(child => traverse(child, depth + 1));
        }
    }

    traverse(obj);
    return patterns;
}

// Основная функция анализа
async function analyzeYFullTree() {
    try {
        console.log('Reading YFull tree data...');
        const data = JSON.parse(fs.readFileSync('c:\\projects\\ftdna_haplo\\data\\ytree.json', 'utf8'));
        
        console.log('\n=== Basic Structure Analysis ===');
        analyzeStructure(data);

        console.log('\n=== Data Patterns ===');
        const patterns = findPatterns(data);
        console.log('Max tree depth:', patterns.maxDepth);
        console.log('Total SNP count:', patterns.snpCount);
        console.log('All possible fields:', [...patterns.uniqueFields].join(', '));
        
        console.log('\nSample nodes at different levels:');
        patterns.sampleNodes.forEach(node => {
            console.log(`Level ${node.depth} - ${node.name}`);
            console.log('Fields:', node.fields.join(', '));
        });

    } catch (error) {
        console.error('Error analyzing YFull tree:', error);
    }
}

// Запускаем анализ
analyzeYFullTree();