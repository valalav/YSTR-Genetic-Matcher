const fs = require('fs');
const { HaploTree } = require('./haplo_functions');

const jsonData = JSON.parse(fs.readFileSync('./data/get.json', 'utf8'));
const haploTree = new HaploTree(jsonData);

// Функция для вывода дерева в консоль
function printTree(node, level = 0) {
    if (!node) return;
    const indent = '  '.repeat(level);
    console.log(`${indent}${node.name} (${node.kitsCount} kits)`);
    
    // Проверяем реальные данные о детях в исходном объекте
    const originalNode = haploTree.haplogroups[node.id];
    if (originalNode && originalNode.children) {
        console.log(`${indent}Original children:`, originalNode.children);
    }
    
    // Выводим построенное дерево
    if (node.children && node.children.length > 0) {
        node.children.forEach(child => printTree(child, level + 1));
    }
}

// Получаем дерево для G-L1264
const l1264 = haploTree.findHaplogroup('G-L1264');
if (l1264) {
    console.log('\nFull tree structure for G-L1264:');
    const tree = haploTree.getSubtree(l1264.haplogroupId);
    printTree(tree);
    
    // Проверяем все уровни вложенности в исходных данных
    console.log('\nChecking all nested levels in raw data:');
    let current = l1264;
    const seen = new Set();
    
    function checkChildren(haplo, level = 0) {
        if (!haplo || seen.has(haplo.haplogroupId)) return;
        seen.add(haplo.haplogroupId);
        
        const indent = '  '.repeat(level);
        console.log(`${indent}${haplo.name} (${haplo.kitsCount} kits) - ID: ${haplo.haplogroupId}`);
        
        if (haplo.children) {
            haplo.children.forEach(childId => {
                const child = haploTree.haplogroups[childId];
                if (child) {
                    checkChildren(child, level + 1);
                }
            });
        }
    }
    
    checkChildren(l1264);
}