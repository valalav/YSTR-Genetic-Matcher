const fs = require('fs');
const { YFullAdapter } = require('./yfull_adapter');

console.log('Loading YFull tree...');
const jsonData = JSON.parse(fs.readFileSync('./data/ytree.json', 'utf8'));
const adapter = new YFullAdapter(jsonData);

function testHaplogroup(snp) {
    console.log(`\nTesting ${snp}:`);
    
    const haplo = adapter.findHaplogroup(snp);
    if (!haplo) {
        console.log('Not found');
        return;
    }

    const details = adapter.getHaplogroupDetails(haplo.haplogroupId);
    console.log('\nPath:');
    console.log(details.path.string);
    
    console.log('\nVariants:');
    details.variants.forEach(v => {
        const alt = v.alternativeNames?.length > 0 ? ` (${v.alternativeNames.join(', ')})` : '';
        console.log(`- ${v.variant}${alt}`);
    });

    if (details.statistics) {
        console.log('\nDating:');
        console.log(`TMRCA: ${details.statistics.tmrca} years ago`);
        console.log(`Formed: ${details.statistics.formed} years ago`);
    }

    if (details.children.length > 0) {
        console.log('\nChildren:');
        details.children.forEach(child => {
            console.log(`- ${child.name} (TMRCA: ${child.tmrca})`);
        });
    }
}

const testSnps = ['M417', 'L1264', 'M198'];
testSnps.forEach(snp => testHaplogroup(snp));