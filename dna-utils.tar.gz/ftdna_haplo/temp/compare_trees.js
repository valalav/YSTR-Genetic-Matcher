const fs = require('fs');
const { YFullTree } = require('./yfull_tree');
const { HaploTree } = require('./haplo_functions');

// Загружаем оба дерева
console.log('Loading trees...');
const yfullData = JSON.parse(fs.readFileSync('./data/ytree.json', 'utf8'));
const ftdnaData = JSON.parse(fs.readFileSync('./data/get.json', 'utf8'));

const yfullTree = new YFullTree(yfullData);
const ftdnaTree = new HaploTree(ftdnaData);

// Функция для сравнения результатов по SNP
function compareSnpResults(snp) {
    console.log(`\nComparing results for SNP: ${snp}`);
    console.log('\nYFull results:');
    
    const yfullResults = yfullTree.searchNodes(snp);
    yfullResults.forEach(result => {
        const details = yfullTree.getNodeDetails(result.node.id);
        console.log(`\nYFull Path:`);
        console.log(details.path.string);
        if (details.snps?.length > 0) {
            console.log('Main SNPs:');
            details.snps.slice(0, 5).forEach(snp => {
                console.log(`- ${snp.primary}${snp.alternatives.length > 0 ? ` (${snp.alternatives.join(', ')})` : ''}`);
            });
        }
        console.log(`TMRCA: ${details.tmrca} years ago`);
    });

    console.log('\nFTDNA results:');
    const ftdnaHaplo = ftdnaTree.findHaplogroup(snp);
    if (ftdnaHaplo) {
        const ftdnaDetails = ftdnaTree.getHaplogroupDetails(ftdnaHaplo.haplogroupId);
        console.log('\nFTDNA Path:');
        console.log(ftdnaDetails.path.string);
        if (ftdnaDetails.variants?.length > 0) {
            console.log('Main SNPs:');
            ftdnaDetails.variants.slice(0, 5).forEach(variant => {
                console.log(`- ${variant.snp}`);
            });
        }
        if (ftdnaDetails.statistics) {
            console.log(`Kits: ${ftdnaDetails.statistics.kitsCount}`);
            console.log(`Sub-branches: ${ftdnaDetails.statistics.subBranches}`);
        }
    } else {
        console.log('Not found in FTDNA tree');
    }
}

// Тестовые SNP для сравнения
const testSnps = [
    'M417',   // R1a
    'L1264',  // G2a
    'M198'    // R1a1
];

testSnps.forEach(snp => compareSnpResults(snp));

// Сравнение статистики
console.log('\nTree Statistics:');
console.log('\nYFull:');
const yfullStats = yfullTree.getNodeStatistics();
console.log(`Total nodes: ${yfullStats.totalNodes}`);
console.log(`Total SNPs: ${yfullStats.totalSnps}`);
console.log(`Age range: ${yfullStats.ageRange.min} - ${yfullStats.ageRange.max} years ago`);

const ftdnaStats = ftdnaTree.getTreeStatistics('1');
console.log('\nFTDNA:');
console.log(`Total nodes: ${Object.keys(ftdnaTree.haplogroups).length}`);
console.log(`Total indexed SNPs: ${ftdnaTree.variantToHaplogroup.size}`);