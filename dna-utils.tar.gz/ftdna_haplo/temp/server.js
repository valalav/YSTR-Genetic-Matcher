const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { HaploTree } = require('../haplo_functions');
const { YFullAdapter } = require('../yfull_adapter');
const { SearchIntegrator } = require('./search_integration');

const app = express();
app.use(cors());
app.use(express.json());

let ftdnaTree = null;
let yfullTree = null;
let searchIntegrator = null;

try {
    console.log('\nLoading FTDNA tree...');
    const ftdnaData = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/get.json'), 'utf8'));
    ftdnaTree = new HaploTree(ftdnaData);
    console.log('FTDNA tree loaded');
   
    console.log('\nLoading YFull tree...');
    const yfullData = JSON.parse(fs.readFileSync(path.join(__dirname, '../data/ytree.json'), 'utf8'));
    yfullTree = new YFullAdapter(yfullData);
    console.log('YFull tree loaded');

    searchIntegrator = new SearchIntegrator(ftdnaTree, yfullTree);
} catch (error) {
    console.error('Error loading trees:', error);
}

app.get('/api/search/:term', async (req, res) => {
    try {
        const { term } = req.params;
        console.log('\nSearch request:', term);

        let ftdnaResult = null;
        let yfullResult = null;
        let ftdnaDetails = null;
        let yfullDetails = null;
        let ftdnaTreeData = null;
        let yfullTreeData = null;

        // Поиск в FTDNA
        ftdnaResult = ftdnaTree.findHaplogroup(term);
        if (ftdnaResult) {
            console.log('Found in FTDNA:', ftdnaResult.name);
            ftdnaDetails = ftdnaTree.getHaplogroupDetails(ftdnaResult.haplogroupId);
            ftdnaTreeData = ftdnaTree.getSubtree(ftdnaResult.haplogroupId);
        } 

        // Поиск в YFull
        yfullResult = yfullTree.findHaplogroup(term);
        if (yfullResult) {
            console.log('Found in YFull:', yfullResult.name);
            yfullDetails = yfullTree.getHaplogroupDetails(yfullResult.haplogroupId);
            yfullTreeData = yfullTree.getSubtree(yfullResult.haplogroupId);
        }

        // Если нашли в FTDNA, но не в YFull
        if (ftdnaResult && !yfullResult) {
            console.log('Looking for YFull match...');
            const yfullMatch = await searchIntegrator.findCorrespondingBranch(term, ftdnaDetails.path.string, 'ftdna');
            if (yfullMatch) {
                console.log('Found YFull match:', yfullMatch.result.name);
                yfullResult = yfullMatch.result;
                yfullDetails = yfullTree.getHaplogroupDetails(yfullResult.haplogroupId);
                yfullTreeData = yfullTree.getSubtree(yfullResult.haplogroupId);
            }
        } 
        // Если нашли в YFull, но не в FTDNA
        else if (!ftdnaResult && yfullResult) {
            console.log('Looking for FTDNA match...');
            const ftdnaMatch = await searchIntegrator.findCorrespondingBranch(term, yfullDetails.path.string, 'yfull');
            if (ftdnaMatch) {
                console.log('Found FTDNA match:', ftdnaMatch.result.name);
                ftdnaResult = ftdnaMatch.result;
                ftdnaDetails = ftdnaTree.getHaplogroupDetails(ftdnaResult.haplogroupId);
                ftdnaTreeData = ftdnaTree.getSubtree(ftdnaResult.haplogroupId);
            }
        }

        // Формируем ответ
        const response = {
            name: term,
            haplogroup: term,
            ftdnaDetails: ftdnaResult && ftdnaDetails ? {
                id: ftdnaDetails.id || ftdnaResult.haplogroupId,
                name: ftdnaResult.name,
                path: ftdnaDetails.path,
                variants: ftdnaDetails.variants,
                statistics: ftdnaDetails.statistics,
                children: ftdnaDetails.children,
                geography: ftdnaDetails.geography,
                source: 'ftdna',
                url: `https://discover.familytreedna.com/y-dna/${ftdnaResult.name}/classic`
            } : null,
            yfullDetails: yfullResult && yfullDetails ? {
                id: yfullDetails.id || yfullResult.haplogroupId,
                name: yfullResult.name,
                path: yfullDetails.path,
                variants: yfullDetails.variants,
                statistics: yfullDetails.statistics,
                children: yfullDetails.children,
                source: 'yfull',
                url: `https://www.yfull.com/tree/${yfullResult.name}/`
            } : null,
            ftdnaTree: ftdnaTreeData,
            yfullTree: yfullTreeData
        };

        res.json(response);
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

app.get('/api/autocomplete', (req, res) => {
    try {
        const { term, limit = 10 } = req.query;
        const ftdnaSuggestions = ftdnaTree.searchWithAutocomplete(term)
            .map(s => ({ ...s, source: 'ftdna' }));
        const yfullSuggestions = yfullTree.searchWithAutocomplete(term)
            .map(s => ({ ...s, source: 'yfull' }));

        const uniqueMap = new Map();
        [...ftdnaSuggestions, ...yfullSuggestions].forEach(item => {
            const existing = uniqueMap.get(item.value);
            if (existing) {
                existing.sources = [...new Set([...existing.sources, item.source])];
            } else {
                uniqueMap.set(item.value, { ...item, sources: [item.source] });
            }
        });

        const unique = Array.from(uniqueMap.values());
        const sorted = unique.sort((a, b) => {
            const aExact = a.value.toUpperCase() === term.toUpperCase();
            const bExact = b.value.toUpperCase() === term.toUpperCase();
            if (aExact !== bExact) return aExact ? -1 : 1;
            if (a.sources.length !== b.sources.length) {
                return b.sources.length - a.sources.length;
            }
            return a.value.length - b.value.length;
        });

        res.json(sorted.slice(0, parseInt(limit)));
    } catch (error) {
        console.error('Autocomplete error:', error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/tree/:haplogroupId', (req, res) => {
    try {
        const { haplogroupId } = req.params;
        const tree = ftdnaTree.getSubtree(haplogroupId);
        if (!tree) {
            return res.status(404).json({ error: 'Haplogroup not found' });
        }
        res.json(tree);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/haplogroups/filter', (req, res) => {
    try {
        const filters = req.body;
        const results = ftdnaTree.filterHaplogroups(filters);
        res.json(results);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = 4000;
app.listen(PORT, () => {
    console.log(`\nServer running on http://localhost:${PORT}`);
});