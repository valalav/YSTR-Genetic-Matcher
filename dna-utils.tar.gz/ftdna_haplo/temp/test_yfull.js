const fs = require('fs');
const { YFullTree } = require('./yfull_tree');

console.log('Loading YFull tree data...');
const jsonData = JSON.parse(fs.readFileSync('./data/ytree.json', 'utf8'));
const tree = new YFullTree(jsonData);

// Тестируем поиск
console.log('\nTesting search for R-M417:');
const searchResults = tree.searchNodes('R-M417');
searchResults.forEach(result => {
    const details = tree.getNodeDetails(result.node.id);
    console.log('\nNode ID:', details.id);
    console.log('TMRCA:', details.tmrca);
    console.log('\nPath:');
    console.log(details.path.string);
    
    console.log('\nSNPs:');
    details.snps.forEach(snp => {
        if (snp.alternatives.length > 0) {
            console.log(`${snp.primary} (also known as ${snp.alternatives.join(', ')})`);
        } else {
            console.log(snp.primary);
        }
    });
    
    if (details.children.length > 0) {
        console.log('\nImmediate children:');
        details.children.forEach(child => {
            console.log(`- ${child.id} (TMRCA: ${child.tmrca})`);
        });
    }
});

// Статистика
console.log('\nTree statistics:');
const globalStats = tree.getNodeStatistics();
console.log(`Total nodes: ${globalStats.totalNodes}`);
console.log(`Total SNPs: ${globalStats.totalSnps}`);
console.log(`Age range: ${globalStats.ageRange.min} - ${globalStats.ageRange.max} years ago`);