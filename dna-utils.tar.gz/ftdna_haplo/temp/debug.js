const fs = require('fs');
const { HaploTree } = require('./haplo_functions');

// Загрузка данных
const jsonData = JSON.parse(fs.readFileSync('./data/get.json', 'utf8'));
const haploTree = new HaploTree(jsonData);

// Поиск конкретной гаплогруппы
console.log('\nSearching for G-L1264...');
const searchTerms = ['G-L1264', 'L1264', 'G2a2', 'GL1264'];

searchTerms.forEach(term => {
    console.log(`\nTrying search term: ${term}`);
    const result = haploTree.findHaplogroup(term);
    if (result) {
        console.log('Found:', {
            name: result.name,
            id: result.haplogroupId,
            variants: result.variants?.map(v => v.variant)
        });
    }
});

// Прямой поиск по всем гаплогруппам
console.log('\nDirect search in all haplogroups...');
let found = false;
for (const [id, haplo] of Object.entries(haploTree.haplogroups)) {
    if (haplo.name && (
        haplo.name === 'G-L1264' || 
        haplo.name.includes('L1264') || 
        haplo.name.includes('G2a2')
    )) {
        found = true;
        console.log('Found haplogroup:', {
            name: haplo.name,
            id: haplo.haplogroupId,
            variants: haplo.variants?.map(v => v.variant)
        });
    }
}

if (!found) {
    console.log('No matching haplogroups found');
}