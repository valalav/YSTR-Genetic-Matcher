export * from './table';
export * from './button';
// ... другие экспорты 
export * from './scroll-area';