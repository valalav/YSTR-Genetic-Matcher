export interface STRMatch {
  profile: {
    haplogroup?: string;
    // ... другие поля профиля
  };
  // ... другие поля
} 